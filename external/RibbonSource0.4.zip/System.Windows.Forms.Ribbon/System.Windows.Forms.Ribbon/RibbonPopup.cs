/*
 
 2008 Jos� Manuel Men�ndez Poo
 * 
 * Please give me credit if you use this code. It's all I ask.
 * 
 * Contact me for more info: menendezpoo@gmail.com
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Design;
using System.ComponentModel;
using System.Drawing.Drawing2D;
using System.Windows.Forms.RibbonHelpers;

namespace System.Windows.Forms
{
    [ToolboxItemAttribute(false)]
    public class RibbonPopup
        : Control
    {
        #region Fields
        private RibbonWrappedDropDown _toolStripDropDown;
        private int _borderRoundness;

        #endregion

        #region Events

        public event EventHandler Showed;

        /// <summary>
        /// Raised when the popup is closed
        /// </summary>
        public event EventHandler Closed;

        /// <summary>
        /// Raised when the popup is about to be closed
        /// </summary>
        public event ToolStripDropDownClosingEventHandler Closing;

        /// <summary>
        /// Raised when the Popup is about to be opened
        /// </summary>
        public event CancelEventHandler Opening;

        #endregion

        #region Ctor

        public RibbonPopup()
        {
            SetStyle(ControlStyles.Opaque, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.Selectable, false);
            BorderRoundness = 3;
        }

        #endregion

        #region Props

        /// <summary>
        /// Gets or sets the roundness of the border
        /// </summary>
        [Browsable(false)]
        public int BorderRoundness
        {
            get { return _borderRoundness; }
            set { _borderRoundness = value; }
        }


        /// <summary>
        /// Gets the related ToolStripDropDown
        /// </summary>
        internal RibbonWrappedDropDown WrappedDropDown
        {
            get { return _toolStripDropDown; }
            set { _toolStripDropDown = value; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Shows this Popup on the specified location of the screen
        /// </summary>
        /// <param name="screenLocation"></param>
        public void Show(Point screenLocation)
        {
            ToolStripControlHost host = new ToolStripControlHost(this);
            WrappedDropDown = new RibbonWrappedDropDown();
            WrappedDropDown.AutoClose = RibbonDesigner.Current != null;
            WrappedDropDown.Items.Add(host);
            
            WrappedDropDown.Padding = Padding.Empty;
            WrappedDropDown.Margin = Padding.Empty;
            host.Padding = Padding.Empty;
            host.Margin = Padding.Empty;

            WrappedDropDown.Opening += new CancelEventHandler(ToolStripDropDown_Opening);
            WrappedDropDown.Closing += new ToolStripDropDownClosingEventHandler(ToolStripDropDown_Closing);
            WrappedDropDown.Closed += new ToolStripDropDownClosedEventHandler(ToolStripDropDown_Closed);
            WrappedDropDown.Size = Size;
            WrappedDropDown.Show(screenLocation);
            RibbonPopupManager.Register(this);

            OnShowed(EventArgs.Empty);
        }
        
        /// <summary>
        /// Handles the Opening event of the ToolStripDropDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripDropDown_Opening(object sender, CancelEventArgs e)
        {
            OnOpening(e);
        }
        
        /// <summary>
        /// Called when pop-up is being opened
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnOpening(CancelEventArgs e)
        {
            if (Opening != null)
            {
                Opening(this, e);
            }
        }

        /// <summary>
        /// Handles the Closing event of the ToolStripDropDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripDropDown_Closing(object sender, ToolStripDropDownClosingEventArgs e)
        {
            OnClosing(e);
        }

        /// <summary>
        /// Handles the closed event of the ToolStripDropDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripDropDown_Closed(object sender, ToolStripDropDownClosedEventArgs e)
        {
            OnClosed(EventArgs.Empty);
        }

        /// <summary>
        /// Closes this popup.
        /// </summary>
        public void Close()
        {
            if (WrappedDropDown != null)
            {
                WrappedDropDown.Close();
            }
        }

        /// <summary>
        /// Raises the <see cref="Closing"/> event
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnClosing(ToolStripDropDownClosingEventArgs e)
        {
            if (Closing != null)
            {
                Closing(this, e);
            }
        }

        /// <summary>
        /// Raises the <see cref="Closed"/> event
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnClosed(EventArgs e)
        {
            RibbonPopupManager.Unregister(this);

            if (Closed != null)
            {
                Closed(this, e);
            }

            //if (NextPopup != null)
            //{
            //    NextPopup.CloseForward();
            //    NextPopup = null;
            //}

            //if (PreviousPopup != null && PreviousPopup.NextPopup.Equals(this))
            //{
            //    PreviousPopup.NextPopup = null;
            //}
        }

        /// <summary>
        /// Raises the Showed event
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnShowed(EventArgs e)
        {
            if (Showed != null)
            {
                Showed(this, e);
            }
        }

        /// <summary>
        /// Raises the <see cref="Paint"/> event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            using (GraphicsPath p = RibbonProfessionalRenderer.RoundRectangle(new Rectangle(Point.Empty, Size), BorderRoundness))
            {
                using (Region r = new Region(p))
                {
                    WrappedDropDown.Region = r;
                }
            }
        }

        /// <summary>
        /// Overriden. Used to drop a shadow on the popup
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;

                if (WinApi.IsXP)
                {
                    cp.ClassStyle |= WinApi.CS_DROPSHADOW;

                }

                return cp;
            }
        }

        #endregion
    }
}
